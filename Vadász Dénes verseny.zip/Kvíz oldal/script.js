const questions = [
    {
        question: "Milyen nemzetiségű volt a három feltaláló?",
        answers: [
            { text: "Német", correct: false},
            { text: "Amerikai", correct: false},
            { text: "Zsidó", correct: true},
            { text: "Szlovák", correct: false},
        ]
    },
    {
        question: "Mit tanított Teller Ede, miután emigrált?",
        answers: [
            { text: "Kvantummechanikát", correct: true},
            { text: "Csillagászatot", correct: false},
            { text: "Matematikát", correct: false},
            { text: "Fizikát", correct: false},
        ]
    },
    {
        question: "Hol halt meg Bánki Donát?",
        answers: [
            { text: "Bakonybánkon", correct: false},
            { text: "New York-ban", correct: false},
            { text: "Bécsben", correct: false},
            { text: "Budapesten", correct: true},
        ]
    },
    {
        question: "Ki segédkezett az atombomba előállításában?",
        answers: [
            { text: "Bánki Donát", correct: false},
            { text: "Neumann János", correct: true},
            { text: "Teller Ede", correct: false},
            { text: "Dr. Lőwinger Ignác", correct: false},
        ]
    },
    {
        question: "Kinek a meghívására emigrált Teller Ede?",
        answers: [
            { text: "Teller Ede", correct: false},
            { text: "Enrico Fermi", correct: false},
            { text: "Pöschl", correct: false},
            { text: "George Gamow", correct: true},
        ]
    },
    {
        question: "Melyik nevezetes országba jutottak el mindannyian életük vége felé?",
        answers: [
            { text: "Amerikába", correct: true},
            { text: "Németországba", correct: false},
            { text: "Egyesült Királyságba", correct: false},
            { text: "Kínába", correct: false},
        ]
    },
    {
        question: "Kit hívtak meg 1930-ban Amerikába?",
        answers: [
            { text: "Trefort Ágostont", correct: false},
            { text: "Ganz Ábrahámot", correct: false},
            { text: "Neumann Jánost", correct: true},
            { text: "George Gamow-ot", correct: false},
        ]
    },
    {
        question: "Ki szabadalmaztatta a robbanómotort?",
        answers: [
            { text: "Teller Ede", correct: false},
            { text: "Bánki Donát", correct: true},
            { text: "Neumann János", correct: false},
            { text: "Neumann Miksa", correct: false},
        ]
    },
    {
        question: "Hol született Neumann János?",
        answers: [
            { text: "Lipcse", correct: false},
            { text: "Bukarest", correct: false},
            { text: "Züich", correct: false},
            { text: "Budapest", correct: true},
        ]
    },
    {
        question: "Mely feltaláló doktorált matematikából 1926-ban?",
        answers: [
            { text: "Enrico Fermi", correct: false},
            { text: "Királyi József", correct: false},
            { text: "Bánki Donát", correct: false},
            { text: "Neumann János", correct: true},
        ]
    },
    {
        question: "Mikor halt meg Teller Ede?",
        answers: [
            { text: "2003", correct: true},
            { text: "1922", correct: false},
            { text: "1957", correct: false},
            { text: "1955", correct: false},
        ]
    },
    {
        question: "Mely tudományi ágban ért el forrdalmi újításokat Neumann János?",
        answers: [
            { text: "Kvantummechanikában", correct: false},
            { text: "Kémiában", correct: false},
            { text: "Informatikában", correct: true},
            { text: "Asztrofizikában", correct: false},
        ]
    }
];

const questionElement = document.getElementById("question");
const answerButtons = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");

let currentQuestionIndex = 0;
let score = 0;

function startQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Következő"
    showQuestion();
}

function showQuestion(){
    resetState();
    let currentQuestion = questions[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.
    question;

    currentQuestion.answers.forEach(answer => {
        const button = document.createElement("button");
        button.innerHTML = answer.text;
        button.classList.add("btn");
        answerButtons.appendChild(button);
        if(answer.correct){
            button.dataset.correct = answer.correct;
        }
        button.addEventListener("click", selectAnswer);
    });
}

function resetState(){
    nextButton.style.display = "none";
    while(answerButtons.firstChild){
        answerButtons.removeChild(answerButtons.firstChild)
    }
}

function selectAnswer(e){
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    if(isCorrect){
        selectedBtn.classList.add("correct");
        score++;
    }else{
        selectedBtn.classList.add("incorrect")
    }
    Array.from(answerButtons.children).forEach(button => {
        if(button.dataset.correct === "true"){
            button.classList.add("correct")
        }
        button.disabled = true;
    });
    nextButton.style.display = "block"
}

function showScore(){
    resetState();
    questionElement.innerHTML = `${questions.length} kérdésből ${score} pontod lett!`;
    nextButton.innerHTML = "Új játék";
    nextButton.style.display = "block";
}

function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex < questions.length){
        showQuestion();
    }else{
        showScore();
    }
}


nextButton.addEventListener("click", ()=>{
    if(currentQuestionIndex < questions.length){
        handleNextButton();
    }else{
        startQuiz();
    }
});


startQuiz();